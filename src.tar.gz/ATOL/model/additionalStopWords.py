'''
AdditionalStopWord = ('january','february','march','april','may','june','july','august',
'september','october','november','december','jan','feb','mar','apr','may',
'jun','jul','aug','sep','oct','nov','dec','sunday','monday','tuesday',
'wednesday','thursday','friday','saturday','mon.','tues.','wed.','thur.',
'fri.','sat.','sun.','javascript','nginx','apache','apache2','http','https',
'darkscandals','onionwallet','day','year','month','days','years','months',
'ahmia','loading','protonmail','plz','please','welcome','index','title',
'username','password','duckduckgo','com','cn','using','use','used','easycoin',
'galaxy','socks5','s7','log','boolean','int','stream','integer','bitmai',
'bitmail','counted','torduckin0','torvps','easycoin','torbox','continue',
'reload','mail2tor','jpg','jpeg','bmp','gif','title','url','content','class',
'style','tabindex','torch','iso','rar','html','zip','exe','pdf','rm','avi',
'tmp','xls','mdf','txt','doc','minute','minutes','hour','hours','seconds',
'second','rgba','la','di','cc','dreamweavers','bitmessage','ubungsmittel',
'yourname','le','aasdda','ja','guerrillamail','log','in','piratecorp','xr',
'using','google','yahoo','alphabay','drugmarket','tempdrop','login','scripts',
'sexymadama','firefox','mozilla','il','cipolla','sarah','fucktofuck010',
'twitter','name','script','function','wpa2a','wp','config','function','desktop',
'desktop','test','desktop','resolution','escrow','today','tomorrow','make',
'hackmanhattan','nt','windows','overcaliber','sigaint','dczakkqt','privnote',
'eucanna','a2a','cos','icq','skype','vtc','przez','parazite','a5','apple',
'samsung','s5','s4','uk','eu','ny','io','ye','afghani','manhattan','fi',
'iphone','mdt','og','b2','marocc','tigas','aol','relatelist','autistici',
'kategorie','deepsec','torshops','freebase','magusnet','openid','lelantos',
'taji','eddie','facebook','odno','cheapeur','tagi','herer','clearnet','kg',
'yourusername','hotmail','asdfgh111','gamerzclan007','tested'

)
'''
AdditionalStopWord = ('javascript',)