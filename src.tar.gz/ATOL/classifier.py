#coding:utf-8
#2017 04 30
#ding

#import 
import numpy as np
from model.classes import doc
from model.funcs import *
from model.config import *
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from TFICF import tf_icfFeature


#testData

#input


#main
TOPN = 1
def classifier(TopKeywords = 0,c_train_label = dict(),c_test_label = dict()):

    #train
    #read train data
    print 'read c_train data from file ...'
    c_train_files = readFiles(c_train_path, c_train_label)
    #k_expert dict->list
    print 'l_train sort and k_expert list ...'
    l_train_sorted, k_expert_list = dict2list(k_expert,l_train)
    #word to id
    print 'c_train init, make dic ...'
    dic, c_train_id, c_train_label, c_train_m, k_expert_id = word2ID( \
    k_expert_list, c_train_files,l_train_sorted, lamda)
    len_dic = len(dic)

    #find keywords()
    print 'find keywords from train set ...'
    M,L = tf_icfFeature(k_expert_id, c_train_id, c_train_m, \
        c_train_label, l_train_sorted, len_dic)
    k_expert_id_updated = []

    for c in xrange(len(l_train_sorted)):
        if c in L:
            l_word = list(M[L.index(c)])
            temp = sorted(l_word, reverse=True)
            temp = temp[0:TopKeywords]
            keywords = []
            for weight in temp:
                if weight >0 :
                    k = l_word.index(weight)
                    keywords.append(k)
                    l_word[k] = 0
            k_expert_id_updated.append(keywords)
        else:
            k_expert_id_updated.append([])

    #print k_expert_id_updated
    #for c in xrange(len(k_expert_id_updated)):
    #    print l_train_sorted[c],':\n'
    #    for k in xrange(len(k_expert_id_updated[c])):
    #        try:
    #            print ' {}'.format(id2word(dic,k_expert_id_updated[c][k]))
    #        except:
    #            print ' {}'.format(k_expert_id_updated[c][k])
    #    print '\n'
    print len(dic)
    #return 0

    #tf-icf
    print 'train data -> tf-icf ...'
    d_train = []
    d_train_l = []
    for docu in xrange(len(c_train_m)):
        M,L = tf_icfFeature(k_expert_id_updated, [c_train_id[docu]], [c_train_m[docu]], \
        [c_train_label[docu]], l_train_sorted, len_dic)
        d_train += M
        d_train_l += L
    print 'Multinomial naive bayes ...'
    ml = MultinomialNB()
    ml.fit(d_train,d_train_l)

    #test
    print 'choice test file ...'
    c_test_files = readFiles(c_test_path, c_test_label)
    c_test_files_id = [doc2id(doc, dic, l_train_sorted) for doc in c_test_files]

    #score
    print 'testing ...'
    test_contents = []
    test_labels = []
    count = 0.0
    right = .0


    # predict_proba test
    for c_test_index in xrange(len(c_test_files_id)):
        count += 1
        content,labels = normalize(c_test_files_id[c_test_index],len_dic)
        temp = ml.predict_proba([content])[0]
        predict_proba_result = [score for score in temp]
        topN = []
        tiao = False

        score = 0.3
        while score >= 0.25:
            score = max(predict_proba_result)
            index = predict_proba_result.index(score)
            topN.append(index)
            predict_proba_result[index] = -1
        #print predict_proba_result
        for c in xrange(len(topN)):
            if topN[c] in labels:
                right +=1
                tiao = True
                break
        if not tiao:
            print '{}-{}'.format([l_train_sorted[c] for c in topN],\
            [l_train_sorted[c] for c in labels])

    print 'test finished: score {}'.format(right/count)
    return right/count
    '''
    for c_test_index in xrange(len(c_test_files_id)):
        count += 1
        content,labels = normalize(c_test_files_id[c_test_index],len_dic)
        predict_result = ml.predict([content])
        #print l_train_sorted[predict_result[0]],',',l_train_sorted[labels[0]]
        #test_contents.append(content)
        #test_labels.append(labels)
        if int(predict_result) in labels:
            right +=1
        else:
            print '{}-{}'.format(l_train_sorted[int(predict_result)],[l_train_sorted[c] for c in labels])
    print 'NB model test finished: score {}'.format(right/count)
    #print 'test finished: score {}'.format(ml.score(test_contents,test_labels))
    return right/count
    '''
'''
    #predict
    #unlabeled docs
    c_unlabel_files = readUnlabelFiles(c_unlabel_path)
    c_unlabel_files_id = [[dic.get(w,-1) for w in file] for file in c_test_files]
    #predict
    for c_unlabel_index in xrange(c_unlabel_files_id):
        predict_result = ml.predict(c_unlabel_files_id[c_unlabel_index])
        prob = ml.predict_proba(c_unlabel_files_id[c_unlabel_index])
'''

if __name__ == '__main__':

    # shi ze jiao cha
    c_train_label = dict(c_train_label_default)
    c_train_label_list = []
    l_train.sort()
    print len(c_train_label)
    for x in xrange(10):
        temp = dict()
        count = 0
        count2 = 0
        for label in l_train:
            urls = [w for w in c_train_label if label in c_train_label[w]]
            num = len(urls)/(10-x)
            count += num
            ids = []
            while num > 0 and len(ids) < num:
                choice = random.randint(0, len(urls) - 1)
                if choice not in ids:
                    ids.append(choice)
            count2 += len(ids)
            for i in ids:
                url = urls[i]
                temp[url] = c_train_label[url]
                del c_train_label[url]
        c_train_label_list.append(temp)
    nb = []
    for j in xrange(10):
        c_t = dict()
        for i in xrange(10):
            if not i == j:
                for k in c_train_label_list[i]:
                    c_t[k] = c_train_label_list[i][k]

        c_test = c_train_label_list[j]
        a = classifier(10,c_train_label=c_t,c_test_label=c_test)
        nb.append(a)
    print 'NB:{}\n'.format(nb)