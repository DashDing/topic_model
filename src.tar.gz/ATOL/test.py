#-*- coding:utf-8 -*-

'''
f = open('/home/ding/Desktop/LDAModel/ATOL/tags','r')
line = f.readline()
topic = ''
topics = []
output = []
while len(line) >0:
    if 'http' in line:
        filename = line.replace('/','_').replace('\n','')
        output.append("'{}':['{}],\n".format(filename,topics))
        #print "'{}':['{}'],".format(domain,topic)
    elif len(line) >= 4:
        topics = line.replace('\n',"'").replace(' ',"', '")
    line = f.readline()
f.close()
f = open('/home/ding/Desktop/LDAModel/ATOL/test.txt','w')
f.writelines(output)
f.close()


from model.config import c_train_label,c_train_path
from model.funcs import *
import re
files = [file for file in c_train_label if 'search engine' in c_train_label[file]]
res = ''
printC = 9
for printC in xrange(len(files)):
    if os.path.exists(c_train_path+files[printC]):
        f=open(c_train_path+files[printC],'r')
        content = f.read()
        f.close()
        code = detectStrEncoding(content)
        content_str = content.decode(code).encode('UTF-8')

        for r in deleteGroup:
            content_str = re.compile(r).sub(' ',content_str)

        soup = BeautifulSoup(content_str, 'lxml')
        content_s = soup.get_text() if not soup.get_text() is None else ''
        print content_s
        title_str = soup.title.string if not soup.title is None else ''
        res += content_s
f = open('/home/ding/Desktop/res','w')
f.write(res.encode('utf8'))




'''

f = open('/home/ding/Desktop/allurls.txt','r')
content = f.readline()
while len(contnet) >0:
    items = content.replace('\n','').split(' ')
    id = items[0]
    url = items[2]
    keys = items[3:len(items)]